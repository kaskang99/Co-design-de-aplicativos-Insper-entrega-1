# Co-design-de-aplicativos-Insper-entrega-1

estrutura da página será:
  home:
    link para 3 casos:
      descrever o casos em páginas separadas
